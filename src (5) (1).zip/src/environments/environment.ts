export const environment={
cognito: {
    userPoolId: 'ap-northeast-1_lfOwmNnZO',
    userPoolWebClientId: '7e0vigupgmvrpi75mrj0d8vn7v',
  },
  s3:
  {
    accesskey:'AKIAZNRGOMHGMC6PRMHW',
    secret:'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',
    region:'Asia Pacific (Tokyo)'
  }
}