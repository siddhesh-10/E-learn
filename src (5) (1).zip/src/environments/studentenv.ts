export const environment={
cognito: {
    userPoolId: 'ap-northeast-1_WlFlVEPaS',
    userPoolWebClientId: '2732ntbdumlfu71ar6ffq0dpgq',
  },
}